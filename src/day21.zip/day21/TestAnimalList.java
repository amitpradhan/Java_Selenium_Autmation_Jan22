package day21;

import java.util.ArrayList;
import java.util.List;

public class TestAnimalList {

    public static void main(String[] args) {
        List<Animal> animalList = new ArrayList<>();
            animalList.add(new Dog("Bulldog"));
            animalList.add(new Cat("Persian"));
//       animalList.get(1).

    }
}
